///Khareen Francis-Proverbs
//Banking App

package main

import (
	"fmt"
	"math"
	"math/rand"
	"time"
)

// create the struct( onstructor in java)
type Account struct {
   Type string
   Balance float32
   FirstName string
   LastName string
   UserID int
}

func (x Account) DisplayBalance()float32{
	fmt.Printf("Your balance is: %.2f", x.Balance)
	fmt.Println("\nThis transaction was completed at",time.Now())
    return x.Balance
}

//supposed to have no parameters
func Deposit(x Account){
	var amount float64
	deposit:
	fmt.Println("Please enter amount to deposit: ")
	fmt.Scanf("%f",&amount)
	balance := float64(x.Balance)+ amount

	if amount <= 0  {
		fmt.Println("\nYou have entered insuffiction balance, please try again")
		goto deposit
	}else{
		fmt.Printf("You have made a total deposit of: %.2f\n",amount)
		fmt.Printf("\nYour new balance is: %.2f",balance)
	}
	fmt.Println("This transaction was completed at",time.Now())
}

func Withdraw(x Account) float32{
	var amount float64
	var balance float64
	
	withdraw:
	fmt.Println("Please enter amount to Withdraw in divisible by 10: ")
	fmt.Scanf("%f",&amount)
	
	balance = float64(x.Balance)-amount

	if amount >= 0 && math.Mod(amount,2)==0{
		balance = float64(x.Balance)-amount
		fmt.Printf("You have made a withdrawal of %.2f\n",amount)
		fmt.Printf("\nYour balance is: %.2f",balance)
	} else{
		fmt.Println("You have entered an incorrect value, Please try again.")
		goto withdraw
	}
	fmt.Println("This transaction was completed at",time.Now())
	return x.Balance
}



func main() {
	min := 10
    max := 99999
	
	var account_num, choice int
	//currentTime := time.Now()
	

	a:=Account{Type: "Checkings" ,FirstName: "Mark" ,LastName: "Mark" , Balance:140,UserID:(rand.Intn(max - min) + min)}
	b:=Account{Type: "Checkings" ,FirstName: "John" ,LastName: "Doe" , Balance:140,UserID:(rand.Intn(max - min) + min)}
	c:=Account{Type: "Savings" ,FirstName: "Jane" ,LastName: "Doe" , Balance:140,UserID:(rand.Intn(max - min) + min)}
	d:=Account{Type: "Savings" ,FirstName: "Sarah" ,LastName: "Gill" , Balance:140,UserID:(rand.Intn(max - min) + min)}
	
	fmt.Println(d.UserID)



	fmt.Println("Please enter your account number:")
	fmt.Scanf("%d",&account_num)

	if account_num == a.UserID{
		fmt.Println("Please select 1. Withdraw")
		fmt.Println("Please select 2. Deposit")
		fmt.Println("Please select 3. Balance")
		fmt.Scanf("%d",&choice)
		if choice == 1 { Withdraw(a)
			
		}else if choice ==2{
			Deposit(a)
		}else if choice ==3{
			a.DisplayBalance()
		}
	}
	if account_num == b.UserID{
		fmt.Println("Please select 1. Withdraw")
		fmt.Println("Please select 2. Deposit")
		fmt.Println("Please select 3. Balance")
		fmt.Scanf("%d",&choice)
		if choice == 1 { Withdraw(b)
			
		}else if choice ==2{
			Deposit(b)
		}else if choice ==3{
			b.DisplayBalance()
		}
	}
	if account_num == c.UserID{
		fmt.Println("Please select 1. Withdraw")
		fmt.Println("Please select 2. Deposit")
		fmt.Println("Please select 3. Balance")
		fmt.Scanf("%d",&choice)
		if choice == 1 { Withdraw(c)
			
		}else if choice ==2{
			Deposit(c)
		}else if choice ==3{
			c.DisplayBalance()
		}
	}
	if account_num == d.UserID{
		fmt.Println("Please select 1. Withdraw")
		fmt.Println("Please select 2. Deposit")
		fmt.Println("Please select 3. Balance")
		fmt.Scanf("%d",&choice)
		if choice == 1 { Withdraw(d)
			
		}else if choice ==2{
			Deposit(d)
		}else if choice ==3{
			d.DisplayBalance()
		}
	}
 }
 