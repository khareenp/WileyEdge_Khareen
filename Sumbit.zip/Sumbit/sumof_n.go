// ACTIVITY 7
// DATATYPES
// Khareen Francis Proverbs

package main

import "fmt"

//calculate the sum of first n natural numbers 1,2,3,4,5,6.....n
func main() {
	n:=7
	sum:=0
	for i:=1;i<= n;i++{
		sum+=sum+i
	}
	fmt.Println(sum)

	

	}
	

	
  
